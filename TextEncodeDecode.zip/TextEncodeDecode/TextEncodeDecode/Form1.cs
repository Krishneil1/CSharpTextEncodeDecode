﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/*This program does not perform data validation Ie it will crash if you try to decode regular expressions e.g Hello World but it will
 Decode encoded text*/
namespace TextEncodeDecode
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var text = textBox1.Text;
            byte[] byt = System.Text.Encoding.UTF8.GetBytes(text);
            var strModified = Convert.ToBase64String(byt);
            label2.Text = Convert.ToString(strModified);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            var text = textBox1.Text;
            byte[] textByte = Convert.FromBase64String(text);
            text = System.Text.Encoding.UTF8.GetString(textByte);
            label3.Text = Convert.ToString(text);
        }
    }
}
